//let name;
//let age;
//name="M.abdelhamed "
//age=19

//console.log(name+age)
//console.log(age);
//console.log(2**4);

//window.prompt('Hello guys');


//let zakah=window.prompt('the amount of zakah');

//document.write(0.025* zakah+' Egyptian pound' )

//console.log(0.025* zakah+' Egyptian pound');

//let Qualify=prompt('Your qualify')
//if(Qualify=='University student')

  // {document.write('welcome University student') }


//else if (Qualify=='school student') 
//{document.write('welcome school student')}
//else {document.write('hello')}

//let birthyear=window.prompt('to calculate your age ')

//document.write(2024-birthyear)












